// the following is a ____

#include "LinkedList.h"
#include <stdio.h>;

// points to first node
struct node *head = NULL;

// points to last node
struct node *last = NULL;

// points to current node
struct node *current = NULL;

// computes length of linked list
 int length() {
   int length = 0;
   struct node *current;
	
   for(current = head; current != NULL; current = current->next){
      length++;
   }
	
   return length;
}

// returns true if linked list is empty and false otherwise
bool isEmpty() {
  if (head == NULL) {
    return true;
  }
    
  else {
    return false;
  }
}
// if it contains the word in the linkedlist, remove it then add // to front with the add method later 
bool contains(char *word){

  struct node *curr;
  for(curr = head; curr != NULL; curr = curr->next)
    if(curr->word == word)
      return true;
  return false;
}

struct node* delete(char *key) {

   //start from the first link
   struct node* current = head;
   struct node* previous = NULL;

   //if list is empty
   if(head == NULL) {
      return NULL;
   }

   //navigate through list
   while(current->word != key) {
      //if it is last node

      if(current->next == NULL) {
         return NULL;
      } else {
         //store reference to current link
         previous = current;

         //move to next link
         current = current->next;
      }
   }
  }

// deletes last element in linked list
void deleteLast() {
  struct node *tempLink = last;
  
  if (isEmpty()) {

  }

  else if (head->next == NULL) {
      head = NULL;
  } 
   
  else {
      last->prev->next = NULL;
  }

  last = last->prev;
  
}

// adds element to the beginning of linked list
void insert(char *word, int freq) {

   struct node *link = (struct node*) malloc(sizeof(struct node));
   link->word = word;
   link->freq = freq;
   struct node *curr;

   if (isEmpty()) {
      last = link;
   } 
   
   else {
      for(curr = head; curr != NULL; curr = curr->next){
        int currfreq = curr->freq;
        if(freq > currfreq || freq == currfreq)
          break;
      }
        curr->prev = link;
   }

   link->next = curr;

   curr = link;
}

// adds element to the beginning of linked list and deletes element if it appears later while keeps elements at 5 or below
void add(char *word) {
  struct node *ptr = head;

  while(ptr != NULL) {
      if (strcmp(ptr->word, word) == 0) {
        ptr->next->prev = ptr->prev;
        ptr->prev->next = ptr->next;
        free(ptr);
        break;
      }
    
      ptr = ptr->next;
   }

  ptr->freq = ptr->freq + 1;
  insert(word, ptr->freq);
  
  if (length() > 5) {
    deleteLast();
  }
}

// displays linked list in its entirety
void display() {

   struct node *ptr = head;

   printf("\n[ ");

   while(ptr != NULL) {
      printf("\"%s\" ",ptr->word);
      ptr = ptr->next;
   }

   printf("]");
}